export const LocalURI = "mongodb://127.0.0.1/media";
export const HostName = "localhost";
export const Secret = "someSecret";