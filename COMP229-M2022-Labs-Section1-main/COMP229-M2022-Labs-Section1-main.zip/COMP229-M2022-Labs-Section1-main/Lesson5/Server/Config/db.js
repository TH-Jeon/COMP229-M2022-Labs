"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Secret = exports.HostName = exports.LocalURI = void 0;
exports.LocalURI = "mongodb://127.0.0.1/media";
exports.HostName = "localhost";
exports.Secret = "someSecret";
//# sourceMappingURL=db.js.map