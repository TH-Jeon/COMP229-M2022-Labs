export const LocalURI = "mongodb://127.0.0.1/media";
//export const RemoteURI = "mongodb+srv://thomas:fYh8xaJ3olIzlJMn@cluster0.o0zosqc.mongodb.net/media?retryWrites=true&w=majority";
export const RemoteURI = process.env.RemoteURI;
export const HostName = "MongoDB Atlas";
export const Secret = "someSecret";