"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Secret = exports.HostName = exports.RemoteURI = exports.LocalURI = void 0;
exports.LocalURI = "mongodb://127.0.0.1/media";
exports.RemoteURI = "mongodb+srv://thomas:9wdp9LWDUheMjGvz@cluster0.vtudhqd.mongodb.net/media?retryWrites=true&w=majority";
exports.HostName = "MongoDB Atlas";
exports.Secret = "someSecret";
//# sourceMappingURL=db.js.map