export const LocalURI = "mongodb://127.0.0.1/media";
export const RemoteURI = "mongodb+srv://thomas:9wdp9LWDUheMjGvz@cluster0.vtudhqd.mongodb.net/media?retryWrites=true&w=majority";
export const HostName = "MongoDB Atlas";
export const Secret = "someSecret";